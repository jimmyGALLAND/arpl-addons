1. kmod.patch: https://raw.githubusercontent.com/fbelavenuto/arpl-addons/v2.50/eudev/src/kmod.patch

2. 50-usb-realtek-net.rules: https://www.realtek.com/zh/component/zoo/category/network-interface-controllers-10-100-1000m-gigabit-ethernet-usb-3-0-software

3. 80-net-name-slot.rules: Incompatible with synology system
